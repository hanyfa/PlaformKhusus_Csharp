﻿using System;

namespace codeblock
{
    class Program
    {
        static void Main(string[] args)
        {
           bool flag = true;
if (flag)
{
    int value = 10;
    Console.WriteLine($"Inside of code block: {value}");
}
        }
    }
}
