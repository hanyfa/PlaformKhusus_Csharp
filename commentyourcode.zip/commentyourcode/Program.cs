﻿using System;

namespace commentyourcode
{
    class Program
    {
        static void Main(string[] args)
        {
            string firstName = "Bob";
int widgetsPurchased = 7;
Console.WriteLine($"{firstName} purchased {widgetsPurchased} widgets.");
        }
    }
}
