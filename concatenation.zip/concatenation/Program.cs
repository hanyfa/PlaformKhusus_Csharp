﻿using System;

namespace concatenation
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello saya hanifah");
        }
    }
}
