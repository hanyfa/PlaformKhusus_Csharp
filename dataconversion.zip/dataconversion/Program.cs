﻿using System;

namespace dataconversion
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello guys my hoby is travelling");
        }
    }
}
