﻿using System;

namespace introducing
{
    class Program
    {
        static void Main(string[] args)
        {
            int number = 7;
string text = "seven";

Console.WriteLine(number);
Console.WriteLine();
Console.WriteLine(text);
        }
    }
}
