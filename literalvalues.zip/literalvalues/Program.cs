﻿using System;

namespace helloworld
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("true");
            Console.WriteLine("false");
        }
    }
}
